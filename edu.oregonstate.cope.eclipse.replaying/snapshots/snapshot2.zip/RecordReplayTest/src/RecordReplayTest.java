public class RecordReplayTest {
	public static void main(String[] args) {
		System.out.println("RecordReplayTest output");
	}
}
